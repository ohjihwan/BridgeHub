import express from 'express';
import http from 'http';
import { Server as IOServer } from 'socket.io';
import { createConnection } from './src/config/db.js';
import setupSignaling from './src/index.js';

const app = express();
const server = http.createServer(app);
const io = new IOServer(server, {
  cors: { origin: process.env.FRONTEND_URL }
});

// DB 연결
createConnection();

// Signaling 서버 셋업
setupSignaling(io);

// RTC-SFU 서버에게도 같은 io 객체 전달 (네임스페이스 사용)
const rtcNsp = io.of('/rtc');
import('./rtc-socket/server.mjs').then(({ initSFU }) => {
  initSFU(rtcNsp);
});

server.listen(process.env.SOCKET_PORT, () => {
  console.log(`Socket server listening on ${process.env.SOCKET_PORT}`);
});
